import type { Request, Response } from 'express';
import { pool } from '../config/database';

// Testa ativamente o banco a cada chamada (não devolve um "ok" fixo).
export async function health(_req: Request, res: Response): Promise<void> {
  const inicio = Date.now();
  try {
    await pool.query({ sql: 'SELECT 1', timeout: 3000 });
    res.json({
      status: 'ok',
      database: 'connected',
      latency_ms: Date.now() - inicio,
      uptime_s: Math.round(process.uptime()),
    });
  } catch (err) {
    console.error('Health check: banco indisponível:', err);
    // Não expõe detalhes do erro (host, usuário etc.) ao cliente.
    res.status(503).json({ status: 'error', database: 'unavailable' });
  }
}
