import type { NextFunction, Request, Response } from 'express';
import { LOTE_STATUS, listarLotes, type FiltroLotes, type LoteStatus } from '../models/lote.model';

// GET /api/lotes?produto_id=1&status=disponivel
export async function listar(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { produto_id, status } = req.query;
    const filtro: FiltroLotes = {};

    if (produto_id !== undefined) {
      if (typeof produto_id !== 'string' || !/^[1-9]\d*$/.test(produto_id)) {
        res.status(400).json({ error: 'produto_id deve ser um inteiro positivo' });
        return;
      }
      filtro.produtoId = Number(produto_id);
    }

    if (status !== undefined) {
      if (typeof status !== 'string' || !(LOTE_STATUS as readonly string[]).includes(status)) {
        res.status(400).json({ error: `status deve ser um de: ${LOTE_STATUS.join(', ')}` });
        return;
      }
      filtro.status = status as LoteStatus;
    }

    const lotes = await listarLotes(filtro);
    res.json({ total: lotes.length, data: lotes });
  } catch (err) {
    next(err);
  }
}
