import mysql from 'mysql2/promise';
import { env } from '../config/env';
import { pool } from '../config/database';
import { DDL } from './schema';

// Cria o banco (se não existir) e as tabelas (se não existirem).
export async function initDatabase(): Promise<void> {
  const { database, ...conexaoSemBanco } = env.db;

  // O banco pode ainda não existir, então esta conexão não seleciona nenhum.
  const conn = await mysql.createConnection({ ...conexaoSemBanco, connectTimeout: 5000 });
  try {
    await conn.query('CREATE DATABASE IF NOT EXISTS ?? CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci', [database]);
  } finally {
    await conn.end();
  }

  for (const statement of DDL) {
    await pool.query(statement);
  }
}
