// DDL do MVP (3 tabelas). Todas as instruções são idempotentes (IF NOT EXISTS),
// então rodar na inicialização a cada start é seguro.
// Mantenha em sincronia com database/schema_mvp.sql (referência legível).
export const DDL: string[] = [
  `CREATE TABLE IF NOT EXISTS produtos (
    id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    sku             VARCHAR(50)  NOT NULL,
    nome            VARCHAR(150) NOT NULL,
    unidade_medida  VARCHAR(10)  NOT NULL,
    UNIQUE KEY uq_produtos_sku (sku)
  ) ENGINE=InnoDB`,

  `CREATE TABLE IF NOT EXISTS lotes (
    id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    produto_id        INT UNSIGNED  NOT NULL,
    numero_lote       VARCHAR(50)   NOT NULL,
    posicao           VARCHAR(20)   NOT NULL,
    data_fabricacao   DATE          NOT NULL,
    data_validade     DATE          NOT NULL,
    qtd_inicial       DECIMAL(12,3) NOT NULL,
    qtd_atual         DECIMAL(12,3) NOT NULL,
    status            ENUM('disponivel', 'consumido', 'vencido') NOT NULL DEFAULT 'disponivel',
    UNIQUE KEY uq_lotes_numero (produto_id, numero_lote),
    KEY ix_lotes_fifo (produto_id, status, data_fabricacao),
    CONSTRAINT chk_lotes_qtd CHECK (qtd_atual >= 0 AND qtd_atual <= qtd_inicial),
    CONSTRAINT fk_lotes_produto FOREIGN KEY (produto_id) REFERENCES produtos (id)
      ON UPDATE CASCADE ON DELETE RESTRICT
  ) ENGINE=InnoDB`,

  `CREATE TABLE IF NOT EXISTS movimentacoes (
    id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    lote_id       INT UNSIGNED  NOT NULL,
    tipo          ENUM('entrada', 'saida') NOT NULL,
    quantidade    DECIMAL(12,3) NOT NULL,
    status        ENUM('sucesso', 'bloqueado_fifo', 'bloqueado_vencido', 'bloqueado_quantidade')
                  NOT NULL DEFAULT 'sucesso',
    observacao    VARCHAR(255)  NULL,
    criado_em     DATETIME      NOT NULL,
    KEY ix_mov_lote (lote_id),
    KEY ix_mov_status_data (status, criado_em),
    CONSTRAINT chk_mov_quantidade CHECK (quantidade > 0),
    CONSTRAINT fk_mov_lote FOREIGN KEY (lote_id) REFERENCES lotes (id)
      ON UPDATE CASCADE ON DELETE RESTRICT
  ) ENGINE=InnoDB`,
];
