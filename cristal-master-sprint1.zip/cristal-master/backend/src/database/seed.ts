import fs from 'node:fs';
import path from 'node:path';
import type { PoolConnection } from 'mysql2/promise';
import { env } from '../config/env';
import { pool } from '../config/database';
import { initDatabase } from './init';

// Carrega no banco os dados gerados por mock/simulator.js.
// Uso (dentro de backend/):  npm run seed
// ATENÇÃO: apaga produtos, lotes e movimentações atuais antes de inserir.

const MOCK_DIR = path.resolve(__dirname, '../../../mock/output');

interface ProdutoMock { id: number; sku: string; nome: string; unidade_medida: string }
interface LoteMock {
  id: number; produto_id: number; numero_lote: string; posicao: string;
  data_fabricacao: string; data_validade: string;
  qtd_inicial: number; qtd_atual: number; status: string;
}
interface MovMock {
  id: number; lote_id: number; tipo: string; quantidade: number;
  status: string; observacao: string | null; criado_em: string;
}

function lerArquivo(nome: string): string {
  const caminho = path.join(MOCK_DIR, nome);
  if (!fs.existsSync(caminho)) {
    throw new Error(
      `Arquivo não encontrado: ${caminho}\nGere os dados antes:  node mock/simulator.js --mode=historico --quantidade=2000`
    );
  }
  return fs.readFileSync(caminho, 'utf-8');
}

async function inserirEmLotes(conn: PoolConnection, sql: string, linhas: unknown[][], tamanho = 1000): Promise<void> {
  for (let i = 0; i < linhas.length; i += tamanho) {
    await conn.query(sql, [linhas.slice(i, i + tamanho)]);
  }
}

async function main(): Promise<void> {
  if (env.nodeEnv === 'production') {
    throw new Error('Seed bloqueado: NODE_ENV=production (ele apaga dados existentes).');
  }

  const produtos: ProdutoMock[] = JSON.parse(lerArquivo('seed_produtos.json'));
  const lotes: LoteMock[] = JSON.parse(lerArquivo('seed_lotes.json'));
  const movs: MovMock[] = lerArquivo('movimentacoes.ndjson')
    .split('\n')
    .filter((linha) => linha.trim() !== '')
    .map((linha) => JSON.parse(linha));

  await initDatabase();

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    // Ordem importa por causa das chaves estrangeiras.
    await conn.query('DELETE FROM movimentacoes');
    await conn.query('DELETE FROM lotes');
    await conn.query('DELETE FROM produtos');

    await inserirEmLotes(
      conn,
      'INSERT INTO produtos (id, sku, nome, unidade_medida) VALUES ?',
      produtos.map((p) => [p.id, p.sku, p.nome, p.unidade_medida])
    );
    await inserirEmLotes(
      conn,
      `INSERT INTO lotes (id, produto_id, numero_lote, posicao, data_fabricacao, data_validade, qtd_inicial, qtd_atual, status)
       VALUES ?`,
      lotes.map((l) => [l.id, l.produto_id, l.numero_lote, l.posicao, l.data_fabricacao, l.data_validade, l.qtd_inicial, l.qtd_atual, l.status])
    );
    await inserirEmLotes(
      conn,
      'INSERT INTO movimentacoes (id, lote_id, tipo, quantidade, status, observacao, criado_em) VALUES ?',
      movs.map((m) => [m.id, m.lote_id, m.tipo, m.quantidade, m.status, m.observacao, m.criado_em])
    );

    await conn.commit();
    console.log(`Seed concluído: ${produtos.length} produtos, ${lotes.length} lotes, ${movs.length} movimentações.`);
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

main()
  .catch((err) => {
    console.error('Seed falhou:', err instanceof Error ? err.message : err);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
