import type { RowDataPacket } from 'mysql2';
import { pool } from '../config/database';

export const LOTE_STATUS = ['disponivel', 'consumido', 'vencido'] as const;
export type LoteStatus = (typeof LOTE_STATUS)[number];

export interface Lote {
  id: number;
  produto_id: number;
  sku: string;
  produto_nome: string;
  numero_lote: string;
  posicao: string;
  data_fabricacao: string;
  data_validade: string;
  qtd_inicial: number;
  qtd_atual: number;
  status: LoteStatus;
}

export interface FiltroLotes {
  produtoId?: number;
  status?: LoteStatus;
}

type LoteRow = Lote & RowDataPacket;

// Lista lotes na ordem FIFO (mais antigo primeiro). Todos os valores vão como
// parâmetros (?), nunca concatenados na query — evita SQL Injection.
export async function listarLotes(filtro: FiltroLotes = {}): Promise<Lote[]> {
  const condicoes: string[] = [];
  const params: Array<number | string> = [];

  if (filtro.produtoId !== undefined) {
    condicoes.push('l.produto_id = ?');
    params.push(filtro.produtoId);
  }
  if (filtro.status !== undefined) {
    condicoes.push('l.status = ?');
    params.push(filtro.status);
  }

  const where = condicoes.length > 0 ? `WHERE ${condicoes.join(' AND ')}` : '';
  const sql = `
    SELECT l.id, l.produto_id, p.sku, p.nome AS produto_nome, l.numero_lote, l.posicao,
           l.data_fabricacao, l.data_validade, l.qtd_inicial, l.qtd_atual, l.status
    FROM lotes l
    INNER JOIN produtos p ON p.id = l.produto_id
    ${where}
    ORDER BY l.data_fabricacao ASC, l.id ASC`;

  const [rows] = await pool.query<LoteRow[]>(sql, params);
  return rows;
}
