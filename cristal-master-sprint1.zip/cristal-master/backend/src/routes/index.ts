import { Router } from 'express';
import { healthRouter } from './health.routes';
import { lotesRouter } from './lotes.routes';

export const routes = Router();

routes.use(healthRouter);
routes.use('/api/lotes', lotesRouter);
