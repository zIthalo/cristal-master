-- ============================================================
-- Cristal Master — PWA Almoxarifado / Controle FIFO
-- Script de criação do schema (MySQL 8.0+)
-- ============================================================
-- Convenções:
--   - InnoDB em todas as tabelas (suporte a FK e transações).
--   - utf8mb4 para suportar acentuação e emojis sem problema.
--   - Chaves primárias BIGINT UNSIGNED AUTO_INCREMENT (crescimento seguro).
--   - Timestamps em UTC, controlados pela aplicação/ORM.
--   - Nenhuma senha em texto puro: senha_hash é gerado com bcrypt.
-- ============================================================

CREATE DATABASE IF NOT EXISTS cristal_master
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE cristal_master;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------
-- 1. PERFIS (RBAC)
-- ------------------------------------------------------------
-- Tabela separada em vez de ENUM fixo no usuário: permite evoluir
-- os perfis (ex.: criar "Auditor") sem alterar a estrutura da tabela
-- usuarios, respeitando o princípio Open/Closed.
CREATE TABLE perfis (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome          VARCHAR(50) NOT NULL,
  descricao     VARCHAR(255) NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT uq_perfis_nome UNIQUE (nome)
) ENGINE=InnoDB;

INSERT INTO perfis (nome, descricao) VALUES
  ('OPERADOR',      'Executa leitura de QR Code e movimentações de estoque'),
  ('SUPERVISOR',    'Aprova exceções de violação FIFO e supervisiona operações'),
  ('ADMINISTRADOR', 'Gerencia usuários, materiais, posições e permissões');

-- ------------------------------------------------------------
-- 2. USUARIOS
-- ------------------------------------------------------------
CREATE TABLE usuarios (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome          VARCHAR(150) NOT NULL,
  email         VARCHAR(190) NOT NULL,
  senha_hash    VARCHAR(255) NOT NULL COMMENT 'bcrypt, nunca texto puro',
  perfil_id     BIGINT UNSIGNED NOT NULL,
  ativo         BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                ON UPDATE CURRENT_TIMESTAMP,

  CONSTRAINT uq_usuarios_email UNIQUE (email),
  CONSTRAINT fk_usuarios_perfil
    FOREIGN KEY (perfil_id) REFERENCES perfis (id)
    ON UPDATE CASCADE
    ON DELETE RESTRICT          -- não permite apagar perfil em uso
) ENGINE=InnoDB;

CREATE INDEX idx_usuarios_perfil_ativo ON usuarios (perfil_id, ativo);

-- ------------------------------------------------------------
-- 3. REFRESH_TOKENS
-- ------------------------------------------------------------
-- Suporta o fluxo JWT + Refresh Token com revogação individual
-- (ex.: logout forçado, troca de dispositivo, detecção de abuso).
CREATE TABLE refresh_tokens (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  usuario_id    BIGINT UNSIGNED NOT NULL,
  token_hash    VARCHAR(255) NOT NULL COMMENT 'hash do refresh token, nunca o token puro',
  expires_at    DATETIME NOT NULL,
  revoked       BOOLEAN NOT NULL DEFAULT FALSE,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT fk_refresh_tokens_usuario
    FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
    ON UPDATE CASCADE
    ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE INDEX idx_refresh_tokens_usuario ON refresh_tokens (usuario_id, revoked);

-- ------------------------------------------------------------
-- 4. MATERIAIS
-- ------------------------------------------------------------
CREATE TABLE materiais (
  id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  codigo          VARCHAR(50) NOT NULL COMMENT 'código interno / SKU',
  descricao       VARCHAR(255) NOT NULL,
  unidade_medida  VARCHAR(10) NOT NULL COMMENT 'ex.: KG, UN, L',
  ativo           BOOLEAN NOT NULL DEFAULT TRUE,
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT uq_materiais_codigo UNIQUE (codigo)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 5. POSICOES (endereço lógico no piso do almoxarifado)
-- ------------------------------------------------------------
-- Representa a fileira/bloco físico (ex.: "F01"), sinalizado por
-- fita/pintura no chão — sem custo de infraestrutura. A regra de
-- negócio é: uma posição ocupada armazena apenas um lote por vez.
CREATE TABLE posicoes (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  codigo        VARCHAR(20) NOT NULL COMMENT 'ex.: F01, F02',
  descricao     VARCHAR(255) NULL,
  ativo         BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT uq_posicoes_codigo UNIQUE (codigo)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 6. LOTES
-- ------------------------------------------------------------
-- O coração da regra FIFO: data_entrada define a ordem de saída.
-- status controla o ciclo de vida do lote.
CREATE TABLE lotes (
  id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  material_id     BIGINT UNSIGNED NOT NULL,
  posicao_id      BIGINT UNSIGNED NOT NULL,
  numero_lote     VARCHAR(50) NOT NULL COMMENT 'identificador físico impresso no QR Code',
  quantidade      DECIMAL(12,3) NOT NULL COMMENT 'ex.: kg de resina, suporta 3 casas decimais',
  data_entrada    DATETIME NOT NULL COMMENT 'define a prioridade FIFO',
  data_validade   DATE NULL,
  status          ENUM('DISPONIVEL', 'CONSUMIDO', 'BLOQUEADO') NOT NULL DEFAULT 'DISPONIVEL',
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                  ON UPDATE CURRENT_TIMESTAMP,

  CONSTRAINT uq_lotes_numero_material UNIQUE (material_id, numero_lote),
  CONSTRAINT chk_lotes_quantidade CHECK (quantidade >= 0),

  CONSTRAINT fk_lotes_material
    FOREIGN KEY (material_id) REFERENCES materiais (id)
    ON UPDATE CASCADE
    ON DELETE RESTRICT,

  CONSTRAINT fk_lotes_posicao
    FOREIGN KEY (posicao_id) REFERENCES posicoes (id)
    ON UPDATE CASCADE
    ON DELETE RESTRICT
) ENGINE=InnoDB;

-- Índice composto: é a consulta mais importante do sistema —
-- "qual o lote mais antigo disponível para este material?"
-- (SELECT ... WHERE material_id = ? AND status = 'DISPONIVEL'
--  ORDER BY data_entrada ASC LIMIT 1)
CREATE INDEX idx_lotes_fifo
  ON lotes (material_id, status, data_entrada);

-- ------------------------------------------------------------
-- 7. ORDENS_PRODUCAO
-- ------------------------------------------------------------
CREATE TABLE ordens_producao (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  numero_op     VARCHAR(50) NOT NULL,
  descricao     VARCHAR(255) NULL,
  status        ENUM('ABERTA', 'EM_ANDAMENTO', 'FINALIZADA', 'CANCELADA')
                NOT NULL DEFAULT 'ABERTA',
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT uq_op_numero UNIQUE (numero_op)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 8. MOVIMENTACOES (log de auditoria + regra FIFO aplicada)
-- ------------------------------------------------------------
-- Toda tentativa de saída é registrada, mesmo quando bloqueada
-- por violação de FIFO — isso é o que torna o controle auditável
-- e tecnicamente defensável perante avaliação.
CREATE TABLE movimentacoes (
  id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  lote_id         BIGINT UNSIGNED NOT NULL COMMENT 'lote efetivamente lido pelo operador',
  usuario_id      BIGINT UNSIGNED NOT NULL COMMENT 'quem executou a leitura',
  op_id           BIGINT UNSIGNED NULL COMMENT 'OP vinculada, quando aplicável',
  aprovado_por    BIGINT UNSIGNED NULL COMMENT 'supervisor que aprovou exceção FIFO',
  tipo            ENUM('ENTRADA', 'SAIDA') NOT NULL,
  quantidade      DECIMAL(12,3) NOT NULL,
  status          ENUM('SUCESSO', 'BLOQUEADO_FIFO', 'EXCECAO_APROVADA')
                  NOT NULL DEFAULT 'SUCESSO',
  justificativa   VARCHAR(500) NULL COMMENT 'obrigatório quando status = EXCECAO_APROVADA',
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT chk_movimentacoes_quantidade CHECK (quantidade > 0),

  CONSTRAINT fk_mov_lote
    FOREIGN KEY (lote_id) REFERENCES lotes (id)
    ON UPDATE CASCADE
    ON DELETE RESTRICT,

  CONSTRAINT fk_mov_usuario
    FOREIGN KEY (usuario_id) REFERENCES usuarios (id)
    ON UPDATE CASCADE
    ON DELETE RESTRICT,

  CONSTRAINT fk_mov_op
    FOREIGN KEY (op_id) REFERENCES ordens_producao (id)
    ON UPDATE CASCADE
    ON DELETE SET NULL,

  CONSTRAINT fk_mov_aprovador
    FOREIGN KEY (aprovado_por) REFERENCES usuarios (id)
    ON UPDATE CASCADE
    ON DELETE SET NULL
) ENGINE=InnoDB;

-- Índices de apoio às consultas de histórico e dashboard
CREATE INDEX idx_mov_lote        ON movimentacoes (lote_id);
CREATE INDEX idx_mov_usuario     ON movimentacoes (usuario_id);
CREATE INDEX idx_mov_status_data ON movimentacoes (status, created_at);

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- Exemplo de consulta central da regra FIFO:
-- "Qual o próximo lote a sair para o material X?"
-- ============================================================
-- SELECT id, numero_lote, posicao_id, data_entrada
-- FROM lotes
-- WHERE material_id = :material_id
--   AND status = 'DISPONIVEL'
-- ORDER BY data_entrada ASC
-- LIMIT 1;
-- ============================================================
