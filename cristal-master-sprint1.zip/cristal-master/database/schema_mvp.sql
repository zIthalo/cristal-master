-- ============================================================
-- Cristal Master — Modelo de Dados Enxuto (MVP / Aula 03)
-- 3 tabelas. Script IDEMPOTENTE: pode ser executado várias vezes.
--
-- ATENÇÃO: o backend cria estas mesmas tabelas automaticamente ao
-- iniciar (backend/src/database/schema.ts). Este arquivo é a
-- referência legível do modelo; se alterar um, altere o outro.
-- ============================================================

CREATE DATABASE IF NOT EXISTS cristal_master
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE cristal_master;

-- ------------------------------------------------------------
-- 1. PRODUTOS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS produtos (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  sku             VARCHAR(50)  NOT NULL,
  nome            VARCHAR(150) NOT NULL,
  unidade_medida  VARCHAR(10)  NOT NULL COMMENT 'ex.: KG, UN, L',

  UNIQUE KEY uq_produtos_sku (sku)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 2. LOTES
-- posicao = endereço lógico no piso (ex.: "F01"), sinalizado por
-- fita/pintura, sem custo de infraestrutura. data_fabricacao define
-- a prioridade FIFO.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lotes (
  id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  produto_id        INT UNSIGNED  NOT NULL,
  numero_lote       VARCHAR(50)   NOT NULL COMMENT 'identificador impresso no QR Code',
  posicao           VARCHAR(20)   NOT NULL,
  data_fabricacao   DATE          NOT NULL,
  data_validade     DATE          NOT NULL,
  qtd_inicial       DECIMAL(12,3) NOT NULL,
  qtd_atual         DECIMAL(12,3) NOT NULL,
  status            ENUM('disponivel', 'consumido', 'vencido') NOT NULL DEFAULT 'disponivel',

  UNIQUE KEY uq_lotes_numero (produto_id, numero_lote),
  -- índice da consulta mais frequente: "lote mais antigo disponível do produto"
  KEY ix_lotes_fifo (produto_id, status, data_fabricacao),
  CONSTRAINT chk_lotes_qtd CHECK (qtd_atual >= 0 AND qtd_atual <= qtd_inicial),
  CONSTRAINT fk_lotes_produto
    FOREIGN KEY (produto_id) REFERENCES produtos (id)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 3. MOVIMENTACOES
-- Registra toda tentativa, inclusive as bloqueadas — é o que
-- permite detectar e auditar anomalias.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS movimentacoes (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  lote_id       INT UNSIGNED  NOT NULL,
  tipo          ENUM('entrada', 'saida') NOT NULL,
  quantidade    DECIMAL(12,3) NOT NULL,
  status        ENUM('sucesso', 'bloqueado_fifo', 'bloqueado_vencido', 'bloqueado_quantidade')
                NOT NULL DEFAULT 'sucesso',
  observacao    VARCHAR(255)  NULL,
  criado_em     DATETIME      NOT NULL,

  KEY ix_mov_lote (lote_id),
  KEY ix_mov_status_data (status, criado_em),
  CONSTRAINT chk_mov_quantidade CHECK (quantidade > 0),
  CONSTRAINT fk_mov_lote
    FOREIGN KEY (lote_id) REFERENCES lotes (id)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ============================================================
-- Consulta central da regra FIFO:
-- SELECT id, numero_lote, posicao, data_fabricacao
-- FROM lotes
-- WHERE produto_id = :produto_id AND status = 'disponivel'
--   AND data_validade >= CURDATE()
-- ORDER BY data_fabricacao ASC, id ASC
-- LIMIT 1;
-- ============================================================
