# /mock — Simulador de Dados Industriais

Script independente (Node.js, sem dependências externas) que simula a rotina do almoxarifado: saídas de material, anomalias e reposição de estoque. Alimenta o banco via `npm run seed` (em `backend/`).

## Como executar

```bash
# Histórico: gera N eventos espalhados no passado, terminando "agora", e encerra
node simulator.js --mode=historico --quantidade=2000

# Contínuo: gera 1 evento a cada X ms, em tempo real (útil para demonstração)
node simulator.js --mode=live --intervalo=2000

# Ajustar a taxa de anomalia nas saídas (padrão 0.10 = 10%)
node simulator.js --mode=historico --quantidade=3000 --anomalia=0.15
```

Aceita de 1 a 100000 eventos (o exercício pede de 1.000 a 5.000). Argumentos inválidos encerram com mensagem de erro.

## Comportamento simulado

| Evento (`tipo` / `status`) | O que representa |
|---|---|
| `saida` / `sucesso` | Saída conforme FIFO: sempre do lote **válido** mais antigo do produto (menor `data_fabricacao`). ~90% das saídas. |
| `saida` / `bloqueado_fifo` | Operador pegou um lote mais novo, pulando o mais antigo — o problema central do desafio. |
| `saida` / `bloqueado_vencido` | Tentativa de dar saída em lote com validade expirada. |
| `saida` / `bloqueado_quantidade` | Pedido maior que o saldo do lote. |
| `entrada` / `sucesso` | Reposição: chega um lote novo do produto com menos estoque. ~6% dos eventos. |

Detalhes que dão realismo:

- **Reposição de estoque:** sem ela o estoque acabaria em poucas centenas de eventos e não existiriam dois lotes do mesmo produto ao mesmo tempo (sem isso, `bloqueado_fifo` seria impossível).
- **Linha do tempo simulada** (modo histórico): intervalo médio de 14 min entre eventos, com variação; 2.000 eventos ≈ 19 dias de operação.
- **Lote vencido nunca sai como `sucesso`:** só aparece como anomalia. Pelo menos 1 lote nasce vencido, garantindo esse cenário obrigatório.
- **Uma posição, um lote:** o endereço do piso (`F01`..`F60`) é alocado preferindo posições livres, como manda a regra organizacional do projeto.
- Só sorteia anomalias possíveis no estado atual (ex.: `bloqueado_fifo` exige 2+ lotes válidos do produto).

## Saída (`mock/output/`, ignorada no Git)

- `seed_produtos.json` — produtos.
- `seed_lotes.json` — lotes com o **estado final** (`qtd_atual` e `status` já refletem as saídas bem-sucedidas).
- `movimentacoes.ndjson` — um evento por linha.

Cada execução sobrescreve os arquivos.
