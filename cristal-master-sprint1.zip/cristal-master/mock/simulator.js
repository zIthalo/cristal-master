#!/usr/bin/env node
/**
 * Cristal Master — Simulador de Dados Industriais (Mock)
 * -------------------------------------------------------
 * Simula a rotina do almoxarifado: saídas de material (operação normal,
 * ~90%), anomalias (~10%) e reposição de estoque (entrada de novos lotes).
 *
 * Eventos gerados (tabela movimentacoes):
 *   tipo=entrada, status=sucesso            -> chegada de um novo lote
 *   tipo=saida,   status=sucesso            -> saída conforme FIFO
 *   tipo=saida,   status=bloqueado_fifo     -> operador pegou lote fora de ordem
 *   tipo=saida,   status=bloqueado_vencido  -> tentativa de sair lote vencido
 *   tipo=saida,   status=bloqueado_quantidade -> pediu mais do que o saldo do lote
 *
 * Uso:
 *   node simulator.js --mode=historico --quantidade=2000
 *   node simulator.js --mode=live --intervalo=2000
 *
 * Flags:
 *   --mode=historico|live   (default: live)
 *   --quantidade=N          eventos no modo histórico, 1 a 100000 (default: 2000)
 *   --intervalo=MS          intervalo entre eventos no modo live (default: 2000)
 *   --anomalia=0.10         probabilidade de anomalia numa saída, 0 a 1 (default: 0.10)
 *
 * Linha do tempo:
 *   historico -> relógio simulado: os eventos são espalhados no passado e
 *                terminam "agora" (ex.: 2000 eventos ~ 20 dias de operação).
 *   live      -> relógio real.
 *
 * Saída (mock/output/, ignorada no Git) — carregada no banco com `npm run seed`
 * dentro de backend/:
 *   seed_produtos.json     produtos
 *   seed_lotes.json        lotes com o ESTADO FINAL (qtd_atual e status já
 *                          refletem todas as movimentações bem-sucedidas)
 *   movimentacoes.ndjson   um evento por linha
 */

const fs = require('fs');
const path = require('path');

// ------------------------------------------------------------
// Configuração via linha de comando
// ------------------------------------------------------------
const args = process.argv.slice(2);

function getArg(name, def) {
  const prefix = `--${name}=`;
  const found = args.find((a) => a.startsWith(prefix));
  return found ? found.slice(prefix.length) : def;
}

function falhar(mensagem) {
  console.error(`Erro: ${mensagem}`);
  process.exit(1);
}

const MODE = getArg('mode', 'live');
const INTERVALO_MS = Number(getArg('intervalo', '2000'));
const QUANTIDADE_HISTORICO = Number(getArg('quantidade', '2000'));
const PROB_ANOMALIA = Number(getArg('anomalia', '0.10'));

if (!['historico', 'live'].includes(MODE)) falhar('--mode deve ser "historico" ou "live".');
if (!Number.isInteger(INTERVALO_MS) || INTERVALO_MS < 100) falhar('--intervalo deve ser um inteiro >= 100 (ms).');
if (!Number.isInteger(QUANTIDADE_HISTORICO) || QUANTIDADE_HISTORICO < 1 || QUANTIDADE_HISTORICO > 100000) {
  falhar('--quantidade deve ser um inteiro entre 1 e 100000.');
}
if (!(PROB_ANOMALIA >= 0 && PROB_ANOMALIA <= 1)) falhar('--anomalia deve estar entre 0 e 1.');

const PROB_ENTRADA = 0.06; // chance de reposição (~equilíbrio: 850 kg x 6% ≈ consumo médio das saídas)
const GAP_MEDIO_MS = 14 * 60 * 1000; // intervalo médio entre eventos no histórico (14 min)
const MS_DIA = 24 * 60 * 60 * 1000;

const OUTPUT_DIR = path.join(__dirname, 'output');
fs.mkdirSync(OUTPUT_DIR, { recursive: true });

// ------------------------------------------------------------
// Utilidades
// ------------------------------------------------------------
function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomFloat(min, max, decimals = 1) {
  return parseFloat((Math.random() * (max - min) + min).toFixed(decimals));
}

function escolher(lista) {
  return lista[randomInt(0, lista.length - 1)];
}

function addMs(date, ms) {
  return new Date(date.getTime() + ms);
}

function toSqlDate(date) {
  return date.toISOString().slice(0, 10);
}

function toSqlDatetime(date) {
  return date.toISOString().slice(0, 19).replace('T', ' ');
}

function arredondar(n) {
  return parseFloat(n.toFixed(3));
}

// ------------------------------------------------------------
// Dados-base
// ------------------------------------------------------------
const PRODUTOS = [
  { id: 1, sku: 'RES-PP-001', nome: 'Resina Polipropileno PP-H', unidade_medida: 'KG' },
  { id: 2, sku: 'RES-PE-002', nome: 'Resina Polietileno PE-AD', unidade_medida: 'KG' },
  { id: 3, sku: 'RES-PVC-003', nome: 'Resina PVC Suspensão', unidade_medida: 'KG' },
  { id: 4, sku: 'ADT-COL-004', nome: 'Aditivo Colorante Master', unidade_medida: 'KG' },
  { id: 5, sku: 'ADT-EST-005', nome: 'Aditivo Estabilizante UV', unidade_medida: 'KG' },
];

// Endereços lógicos do piso (fita/pintura no chão): F01..F60
const POSICOES = Array.from({ length: 60 }, (_, i) => `F${String(i + 1).padStart(2, '0')}`);

// ------------------------------------------------------------
// Estado da simulação
// ------------------------------------------------------------
const estado = {
  agora: new Date(),
  lotes: [],
  proximoLoteId: 1,
  proximaMovId: 1,
};

function hoje() {
  return toSqlDate(estado.agora);
}

// Regra "uma posição = um lote": prefere posição ainda livre.
function posicaoLivre() {
  const usadas = new Set(estado.lotes.filter((l) => l.qtd_atual > 0).map((l) => l.posicao));
  const livres = POSICOES.filter((p) => !usadas.has(p));
  return escolher(livres.length > 0 ? livres : POSICOES);
}

function criarLote(produto, dataFabricacao, dataValidade, quantidade) {
  const n = estado.lotes.filter((l) => l.produto_id === produto.id).length + 1;
  const lote = {
    id: estado.proximoLoteId++,
    produto_id: produto.id,
    numero_lote: `L${String(produto.id).padStart(2, '0')}${String(n).padStart(3, '0')}`,
    posicao: posicaoLivre(),
    data_fabricacao: toSqlDate(dataFabricacao),
    data_validade: toSqlDate(dataValidade),
    qtd_inicial: quantidade,
    qtd_atual: quantidade,
    status: 'disponivel',
  };
  estado.lotes.push(lote);
  return lote;
}

// Estoque inicial: lotes de idades variadas; ~8% (mínimo 1) já vencidos.
function gerarLotesIniciais(inicio) {
  const total = [];
  PRODUTOS.forEach((produto) => {
    const qtdLotes = randomInt(4, 8);
    for (let i = 0; i < qtdLotes; i++) total.push(produto);
  });

  const indicesVencidos = new Set();
  const qtdVencidos = Math.max(1, Math.round(total.length * 0.08));
  while (indicesVencidos.size < qtdVencidos) indicesVencidos.add(randomInt(0, total.length - 1));

  total.forEach((produto, idx) => {
    let fabricacao;
    let validade;
    if (indicesVencidos.has(idx)) {
      // estoque encalhado: fabricado há muito tempo, validade curta já expirada
      fabricacao = addMs(inicio, -randomInt(100, 200) * MS_DIA);
      validade = addMs(fabricacao, randomInt(60, 90) * MS_DIA);
    } else {
      fabricacao = addMs(inicio, -randomInt(1, 60) * MS_DIA);
      validade = addMs(fabricacao, randomInt(90, 180) * MS_DIA);
    }
    criarLote(produto, fabricacao, validade, randomFloat(500, 1200, 1));
  });
}

// ------------------------------------------------------------
// Consultas de estado
// ------------------------------------------------------------
function ordemFifo(a, b) {
  if (a.data_fabricacao !== b.data_fabricacao) return a.data_fabricacao < b.data_fabricacao ? -1 : 1;
  return a.id - b.id;
}

function lotesValidos() {
  const h = hoje();
  return estado.lotes.filter((l) => l.status === 'disponivel' && l.qtd_atual > 0 && l.data_validade >= h);
}

function lotesVencidosComSaldo() {
  const h = hoje();
  return estado.lotes.filter((l) => l.status === 'disponivel' && l.qtd_atual > 0 && l.data_validade < h);
}

// ------------------------------------------------------------
// Geração de eventos
// ------------------------------------------------------------
function novaMov(lote, tipo, quantidade, status, observacao) {
  return {
    id: estado.proximaMovId++,
    lote_id: lote.id,
    tipo,
    quantidade,
    status,
    observacao,
    criado_em: toSqlDatetime(estado.agora),
  };
}

// Reposição: chega um lote novo do produto com menos estoque válido.
function gerarEntrada() {
  const validos = lotesValidos();
  const saldoPorProduto = PRODUTOS.map((p) => ({
    produto: p,
    saldo: validos.filter((l) => l.produto_id === p.id).reduce((s, l) => s + l.qtd_atual, 0),
  }));
  const menor = Math.min(...saldoPorProduto.map((x) => x.saldo));
  const produto = escolher(saldoPorProduto.filter((x) => x.saldo === menor)).produto;

  const validade = addMs(estado.agora, randomInt(90, 180) * MS_DIA);
  const lote = criarLote(produto, estado.agora, validade, randomFloat(500, 1200, 1));
  return novaMov(lote, 'entrada', lote.qtd_inicial, 'sucesso', `Entrada do lote ${lote.numero_lote} na posição ${lote.posicao}`);
}

function quantidadeNormal(lote) {
  // nunca retira mais do que existe; lote com pouco saldo é retirado por inteiro
  return arredondar(Math.min(randomFloat(10, 120, 1), lote.qtd_atual));
}

function aplicarSaida(lote, quantidade) {
  lote.qtd_atual = arredondar(lote.qtd_atual - quantidade);
  if (lote.qtd_atual <= 0) {
    lote.qtd_atual = 0;
    lote.status = 'consumido';
  }
}

function gerarSaida() {
  const validos = lotesValidos();
  if (validos.length === 0) return null;

  const produto = escolher([...new Set(validos.map((l) => l.produto_id))]);
  const doProduto = validos.filter((l) => l.produto_id === produto).sort(ordemFifo);
  const loteCorreto = doProduto[0]; // mais antigo = regra FIFO

  if (Math.random() < PROB_ANOMALIA) {
    // só sorteia anomalias que são possíveis no estado atual do estoque
    const tipos = ['quantidade'];
    if (doProduto.length > 1) tipos.push('fifo');
    if (lotesVencidosComSaldo().length > 0) tipos.push('vencido');

    const tipo = escolher(tipos);

    if (tipo === 'fifo') {
      const lote = escolher(doProduto.slice(1));
      return novaMov(
        lote, 'saida', quantidadeNormal(lote), 'bloqueado_fifo',
        `Lote ${lote.numero_lote} fora de ordem (correto: ${loteCorreto.numero_lote})`
      );
    }
    if (tipo === 'vencido') {
      const lote = escolher(lotesVencidosComSaldo());
      return novaMov(
        lote, 'saida', quantidadeNormal(lote), 'bloqueado_vencido',
        `Lote ${lote.numero_lote} vencido em ${lote.data_validade}`
      );
    }
    const pedido = arredondar(loteCorreto.qtd_atual + randomFloat(50, 200, 1));
    return novaMov(
      loteCorreto, 'saida', pedido, 'bloqueado_quantidade',
      `Pedido de ${pedido} acima do saldo de ${loteCorreto.qtd_atual} do lote ${loteCorreto.numero_lote}`
    );
  }

  const quantidade = quantidadeNormal(loteCorreto);
  aplicarSaida(loteCorreto, quantidade);
  return novaMov(loteCorreto, 'saida', quantidade, 'sucesso', 'Saída conforme FIFO');
}

function proximoEvento() {
  const reposicao = Math.random() < PROB_ENTRADA || lotesValidos().length === 0;
  return reposicao ? gerarEntrada() : gerarSaida() || gerarEntrada();
}

// ------------------------------------------------------------
// Persistência em arquivo
// ------------------------------------------------------------
function salvarJson(nomeArquivo, dado) {
  fs.writeFileSync(path.join(OUTPUT_DIR, nomeArquivo), JSON.stringify(dado, null, 2), 'utf-8');
}

function salvarLotes() {
  salvarJson('seed_lotes.json', estado.lotes);
}

function anexarMov(mov) {
  fs.appendFileSync(path.join(OUTPUT_DIR, 'movimentacoes.ndjson'), JSON.stringify(mov) + '\n', 'utf-8');
}

// ------------------------------------------------------------
// Execução
// ------------------------------------------------------------
function main() {
  console.log(`Simulador Cristal Master — modo: ${MODE}`);

  const agoraReal = new Date();
  estado.agora =
    MODE === 'historico' ? addMs(agoraReal, -QUANTIDADE_HISTORICO * GAP_MEDIO_MS) : agoraReal;

  gerarLotesIniciais(estado.agora);
  salvarJson('seed_produtos.json', PRODUTOS);
  salvarLotes();
  fs.writeFileSync(path.join(OUTPUT_DIR, 'movimentacoes.ndjson'), '', 'utf-8');

  const contagem = {};

  function emitir() {
    const mov = proximoEvento();
    anexarMov(mov);
    const chave = `${mov.tipo}/${mov.status}`;
    contagem[chave] = (contagem[chave] || 0) + 1;
    return mov;
  }

  if (MODE === 'historico') {
    for (let i = 0; i < QUANTIDADE_HISTORICO; i++) {
      estado.agora = new Date(
        Math.min(agoraReal.getTime(), estado.agora.getTime() + GAP_MEDIO_MS * randomFloat(0.2, 1.8, 2))
      );
      emitir();
    }
    salvarLotes();
    console.log(`Gerados ${QUANTIDADE_HISTORICO} eventos em ${path.join('mock', 'output')}:`);
    console.table(contagem);
    return;
  }

  setInterval(() => {
    estado.agora = new Date();
    const mov = emitir();
    salvarLotes();
    console.log(`[${mov.criado_em}] ${mov.tipo} lote=${mov.lote_id} qtd=${mov.quantidade} status=${mov.status}`);
  }, INTERVALO_MS);
}

main();
